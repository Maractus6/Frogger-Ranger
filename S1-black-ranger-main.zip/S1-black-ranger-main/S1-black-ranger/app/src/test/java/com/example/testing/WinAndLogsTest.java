package com.example.testing;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import android.graphics.Rect;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class WinAndLogsTest {
    @Test
    public void hitLeftBorderTest() {
        DrawGameObjects dgo = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = Mockito.mock(GameSettings.class);
        Collision collision = Mockito.mock(Collision.class);
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        doCallRealMethod().when(dgo).setPlayer(player);
        dgo.setPlayer(player);
        doCallRealMethod().when(dgo).setGame(game);
        dgo.setGame(game);
        doCallRealMethod().when(dgo).setCollision(collision);
        dgo.setCollision(collision);
        doCallRealMethod().when(game).setStartingLives(1);
        game.setStartingLives(1);
        doCallRealMethod().when(player).setXCord(-50);
        player.setXCord(-50);
        doCallRealMethod().when(collision).setCollided(true);
        collision.setCollided(true);
        doCallRealMethod().when(dgo).resetRound();
        doCallRealMethod().when(dgo).playerHitBorder();
        dgo.playerHitBorder();
        dgo.resetRound();
        doCallRealMethod().when(game).getStartingLives();
        assertEquals(1, game.getStartingLives());
    }
    @Test
    public void hitRightBorderTest() {
        DrawGameObjects dgo = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = Mockito.mock(GameSettings.class);
        Collision collision = Mockito.mock(Collision.class);
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        doCallRealMethod().when(dgo).setPlayer(player);
        dgo.setPlayer(player);
        doCallRealMethod().when(dgo).setGame(game);
        dgo.setGame(game);
        doCallRealMethod().when(dgo).setCollision(collision);
        dgo.setCollision(collision);
        doCallRealMethod().when(game).setStartingLives(1);
        game.setStartingLives(1);
        doCallRealMethod().when(player).setXCord(950);
        player.setXCord(950);
        doCallRealMethod().when(collision).setCollided(true);
        collision.setCollided(true);
        doCallRealMethod().when(dgo).resetRound();
        doCallRealMethod().when(dgo).playerHitBorder();
        dgo.playerHitBorder();
        dgo.resetRound();
        doCallRealMethod().when(game).getStartingLives();
        assertEquals(1, game.getStartingLives());
    }

    @Test
    public void touchingLogTest() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        Rect rectangleEnemy = Mockito.mock(Rect.class);
        Collision collided = Mockito.mock(Collision.class);
        MonsterLog log = Mockito.mock(MonsterLog.class);

//        doCallRealMethod().when(rectangle).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangle.set(120 + 45, 980 + 100 + 60, 120 + 100 + 45, 980 + 60);
//        doCallRealMethod().when(rectangleEnemy).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangleEnemy.set(120 + 45, 1150, 500 + 150, 1000);
        doCallRealMethod().when(log).setRectangle(rectangleEnemy);
        log.setRectangle(rectangleEnemy);

        GameSettings game = Mockito.mock(GameSettings.class);
        doCallRealMethod().when(player).setGame(game);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        player.setGame(game);

        boolean collidedBool = true;
        doCallRealMethod().when(collided).checkCollision(player, rectangle, rectangleEnemy);
        doCallRealMethod().when(log).getRectangle();
        collided.checkCollision(player, rectangle, log.getRectangle());
        doCallRealMethod().when(collided).getCollided();
        boolean checkBool = collided.getCollided();
        assertEquals(collidedBool, checkBool);
    }

    @Test
    public void checkLogMovesRight() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterLog log = Mockito.mock(MonsterLog.class);
        int x = 0;
        when(log.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(log).setXCord(x);
        when(log.getXCord()).thenCallRealMethod();
        log.setXCord(x);
        int shift = 40;
        doCallRealMethod().when(log).setXCord(shift);
        log.setXCord(shift);
        assertEquals(shift, log.getXCord());
    }
    public void movingWithLogTest() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        int y = 520;
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int x = 50;
        doCallRealMethod().when(player).setXCord(x);
        player.setXCord(x);
        rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        doCallRealMethod().when(player).moveWithLog();
        player.moveWithLog();
        doCallRealMethod().when(player).getXCord();
        assertEquals(x + 20, player.getXCord());
    }

    @Test
    public void movingWithLogTest2() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        int y = 390;
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int x = 200;
        doCallRealMethod().when(player).setXCord(x);
        player.setXCord(x);
        rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        doCallRealMethod().when(player).moveWithLog();
        player.moveWithLog();
        doCallRealMethod().when(player).getXCord();
        assertEquals(x - 100, player.getXCord());
    }


    @Test
    public void checkLastScore(){
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = new GameSettings();
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        int score = 24;
        //doCallRealMethod().when(game).setScore(score);
        game.setScore(score);
        int y = 130;
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int shift = 80;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        int defaultVal = 0;
        int difference = 6;
        int newScore = score+difference;
        game.setScore(newScore);
        assertEquals("30", game.getScore());
        game.setScore(defaultVal);
    }

    @Test
    public void checkGoalScore(){
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = new GameSettings();
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        int score = 24;
        //doCallRealMethod().when(game).setScore(score);
        game.setScore(score);
        int y = 130;
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int shift = 80;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        int defaultVal = 0;
        int newScore = 30;
        int oldScore = Integer.valueOf(game.getScore());
        game.setScore(newScore);
        int difference = Integer.valueOf(game.getScore()) - oldScore;
        assertEquals(6, difference);
        game.setScore(defaultVal);

    @Test
    public void checkLogMovesLeft() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterLog log = Mockito.mock(MonsterLog.class);
        int x = 0;
        when(log.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(log).setXCord(x);
        when(log.getXCord()).thenCallRealMethod();
        log.setXCord(x);
        int shift = -40;
        doCallRealMethod().when(log).setXCord(shift);
        log.setXCord(shift);
        assertEquals(shift,log.getXCord());
    }
    @Test
    public void checkWinRestartScore() {
        GameSettings gameSettings = new GameSettings();
        gameSettings.setScore(25);
        gameSettings.setStartingLives(0);
        gameSettings.setGameOver(true);
        GameSettings gameRestart = new GameSettings();
        assertEquals("0",gameRestart.getScore());

    }
}
