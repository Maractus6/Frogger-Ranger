package com.example.testing;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.doCallRealMethod;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import android.graphics.Rect;


import com.example.testing.Collision;
import com.example.testing.DrawGameObjects;
import com.example.testing.GameSettings;
import com.example.testing.Player;

import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

public class GameOverAndCollisionsTest {
    @Test

    public void checkLastScore(){
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = new GameSettings();
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        String difficulty = "Hard";
        //doCallRealMethod().when(game).setDifficulty(difficulty);
        game.setDifficulty(difficulty);
        int score = 2;
        //doCallRealMethod().when(game).setScore(score);
        game.setScore(score);
        //when(game.getStartingLives()).thenCallRealMethod();
        int newLives = game.getStartingLives()-1;
        //doCallRealMethod().when(game).setStartingLives(newLives);
        game.setStartingLives(newLives);
        int newLives2 = game.getStartingLives()-1;;
        //doCallRealMethod().when(game).setStartingLives(newLives2);
        game.setStartingLives(newLives2);
        int defaultVal = 0;
        //when(game.getScore()).thenCallRealMethod();
        //doCallRealMethod().when(game).setScore(score);
        game.setScore(score);
        assertEquals("2", game.getScore());
        assertEquals(true, game.getGameOver());
        game.setScore(defaultVal);
    }

    @Test
    public void checkRestartScore(){
        GameSettings game = new GameSettings();
        game.setScore(10);
        game.setStartingLives(0);
        game.setGameOver(true);

        GameSettings restartedGame = new GameSettings();
        assertEquals("0", restartedGame.getScore());
    }

    public void touchingWaterTest() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        Collision collided = Mockito.mock(Collision.class);
        doCallRealMethod().when(rectangle).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        GameSettings game = Mockito.mock(GameSettings.class);
        doCallRealMethod().when(player).setGame(game);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        player.setGame(game);
        Boolean collidedBool = true;
        doCallRealMethod().when(collided).checkCollision(player, rectangle, rectangle);
        collided.checkCollision(player, rectangle, rectangle);
        doCallRealMethod().when(collided).getCollided();
        Boolean checkBool = collided.getCollided();

//        int livesStart = 2;
//        doCallRealMethod().when(game).setStartingLives(livesStart);
//        game.setStartingLives(livesStart);
//        int y = 720;
//        doCallRealMethod().when(player).setYCord(y);
//        player.setYCord(y);
//        int shift = 80;
//        doCallRealMethod().when(player).setShift(shift);
//        player.setShift(shift);
//        doCallRealMethod().when(player).up();
//        player.up();
//        DrawGameObjects dgo = Mockito.mock(DrawGameObjects.class);
//        Collision collision = Mockito.mock(Collision.class);
//        boolean bool = true;
//        doCallRealMethod().when(collision).setCollided(bool);
//        collision.setCollided(bool);
//        doCallRealMethod().when(dgo).setPlayer(player);
//        dgo.setPlayer(player);
//        doCallRealMethod().when(dgo).setCollision(collision);
//        dgo.setCollision(collision);
//        doCallRealMethod().when(dgo).setGame(game);
//        dgo.setGame(game);
//        doCallRealMethod().when(dgo).resetRound();
//        dgo.resetRound();
//        doCallRealMethod().when(game).getStartingLives();
//        int lives = game.getStartingLives();
        //doCallRealMethod().when(game).getStartingLives();
        assertEquals(collidedBool, checkBool);
    }

    @Test
    public void touchingWaterTest2() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        Rect rectangleEnemy = Mockito.mock(Rect.class);
        Collision collided = Mockito.mock(Collision.class);
        doCallRealMethod().when(rectangle).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangle.set(120 + 45, 180 + 100 + 60, 120 + 100 + 45, 180 + 60);
        GameSettings game = Mockito.mock(GameSettings.class);
        doCallRealMethod().when(player).setGame(game);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        player.setGame(game);
        Boolean collidedBool = true;
        doCallRealMethod().when(collided).checkCollision(player, rectangle, rectangle);
        collided.checkCollision(player, rectangle, rectangle);
        doCallRealMethod().when(collided).getCollided();
        Boolean checkBool = collided.getCollided();
        assertEquals(collidedBool, checkBool);
    }

    @Test
    public void CatCollisionTest() {
        Player player = Mockito.mock(Player.class);
        Rect playerHitbox = Mockito.mock(Rect.class);
        MonsterCat cat = Mockito.mock(MonsterCat.class);
        Rect catHitBox = Mockito.mock(Rect.class);
        Collision collided = Mockito.mock(Collision.class);
        doCallRealMethod().when(playerHitbox)
                .set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        playerHitbox.set(120 + 45, 980 + 100 + 60, 120 + 100 + 45, 980 + 60);
        doCallRealMethod().when(catHitBox)
                .set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        catHitBox.set(120 + 45, 880 + 100 + 60, 120 + 100 + 45, 880 + 6);
        doCallRealMethod().when(player).setRectangle(playerHitbox);
        player.setRectangle(playerHitbox);
        doCallRealMethod().when(cat).setRectangle(catHitBox);
        cat.setRectangle(catHitBox);
        GameSettings game = Mockito.mock(GameSettings.class);
        player.setGame(game);
        Boolean collidedBool = true;
        doCallRealMethod().when(collided).checkCollision(player, catHitBox, playerHitbox);
        doCallRealMethod().when(cat).getRectangle();
        doCallRealMethod().when(player).getRectangle();
        collided.checkCollision(player, cat.getRectangle(), player.getRectangle());
        doCallRealMethod().when(collided).getCollided();
        Boolean checkBool = collided.getCollided();
        assertEquals(collidedBool, checkBool);

    }
    @Test
    public void resetPlayerTest() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        Rect rectangle2 = Mockito.mock(Rect.class);
        int x = 460;
        int y = 1290;
        rectangle.set(120 + 45, 980 + 100 + 60, 120 + 100 + 45, 980 + 60);
        rectangle2.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        doCallRealMethod().when(player).resetCharacter();
        player.resetCharacter();
        assertEquals(rectangle2.left, rectangle.left);
        assertEquals(rectangle2.right, rectangle.right);
        assertEquals(rectangle2.top, rectangle.top);
        assertEquals(rectangle2.bottom, rectangle.bottom);

    }

    @Test
    public void touchingLizardTest() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        Rect rectangleEnemy = Mockito.mock(Rect.class);
        Collision collided = Mockito.mock(Collision.class);
        MonsterLizard lizard = Mockito.mock(MonsterLizard.class);

        doCallRealMethod().when(rectangle).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangle.set(120 + 45, 980 + 100 + 60, 120 + 100 + 45, 980 + 60);
        doCallRealMethod().when(rectangleEnemy).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangleEnemy.set(120 + 45, 1150, 500 + 150, 1000);
        doCallRealMethod().when(lizard).setRectangle(rectangleEnemy);
        lizard.setRectangle(rectangleEnemy);

        GameSettings game = Mockito.mock(GameSettings.class);
        doCallRealMethod().when(player).setGame(game);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        player.setGame(game);

        boolean collidedBool = true;
        doCallRealMethod().when(collided).checkCollision(player, rectangle, rectangleEnemy);
        doCallRealMethod().when(lizard).getRectangle();
        collided.checkCollision(player, rectangle, lizard.getRectangle());
        doCallRealMethod().when(collided).getCollided();
        boolean checkBool = collided.getCollided();
        assertEquals(collidedBool, checkBool);
    }

    @Test
    public void touchingPumpkinTest() {
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        Rect rectangleEnemy = Mockito.mock(Rect.class);
        Collision collided = Mockito.mock(Collision.class);
        MonsterPumpkin pumpkin = Mockito.mock(MonsterPumpkin.class);

        doCallRealMethod().when(rectangle).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangle.set(120 + 45, 980 + 100 + 60, 120 + 100 + 45, 980 + 60);
        doCallRealMethod().when(rectangleEnemy).set(120 + 45, 720 + 100 + 60, 120 + 100 + 45, 720 + 60);
        rectangleEnemy.set(120, 1150 - 45, 500 + 105, 955);
        doCallRealMethod().when(pumpkin).setRectangle(rectangleEnemy);
        pumpkin.setRectangle(rectangleEnemy);

        GameSettings game = Mockito.mock(GameSettings.class);
        doCallRealMethod().when(player).setGame(game);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        player.setGame(game);

        boolean collidedBool = true;
        doCallRealMethod().when(collided).checkCollision(player, rectangle, rectangleEnemy);
        doCallRealMethod().when(pumpkin).getRectangle();
        collided.checkCollision(player, rectangle, pumpkin.getRectangle());
        doCallRealMethod().when(collided).getCollided();
        boolean checkBool = collided.getCollided();
        assertEquals(collidedBool, checkBool);
    }

    @Test
    public void hitBoxMovesWithPlayerDownTest() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        int y = 1000;
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int shift = 60;
        int x = 460;
        rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
        doCallRealMethod().when(player).setRectangle(rectangle);
        player.setRectangle(rectangle);
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        player.down();
        assertEquals(player.getYCord(), rectangle.top);
    }

    @Test
    public void hitBoxMovingTestUp() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        int y = 999;
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int shift = 59;
        int x = 459;
        rectangle.set(x - 45, y - 100 - 60, x - 100 + 45, y - 60);
        doCallRealMethod().when(player).setRectangle(rectangle);
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        player.up();
        assertEquals(player.getYCord(),rectangle.top);
    }

    @Test
    public void hitBoxMovingTestRight() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        Rect rectangle = Mockito.mock(Rect.class);
        int y = 999;
        int shift = 59;
        int x = 459;
        rectangle.set(x - 45, y - 100 - 60, x - 100 + 45, y - 60);
        doCallRealMethod().when(player).setRectangle(rectangle);
        doCallRealMethod().when(player).setShift(shift);
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        player.setShift(shift);
        player.right();
        assertEquals(player.getXCord(),rectangle.right);
    }


}

