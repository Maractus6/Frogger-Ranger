package com.example.testing;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class GameSettingsTest {

//    @Mock
//    GameSettings player = Mockito.mock(GameSettings.class);

    @Mock
    ConfigScreen screen;
    

    @Test
    public void setPlayerNameCorrectTest() {
        // Tests if the name has been set correctly
        GameSettings player = Mockito.mock(GameSettings.class);
        String name = "sudghfksehfw";
        player.setName(name);
        when(player.getName()).thenReturn(name);
        assertEquals(name, player.getName());
    }
    @Test
    public void setNameIncorrectTest () {
        //Tests if {null name input} works
        GameSettings player = Mockito.mock(GameSettings.class);
        GameSettings game = new GameSettings();
        String name = "";
        game.setName(null);
        assertEquals("object not equal", "Invalid Input", game.getName());

        //Tests if {whitespace name input} works
        name = "  ";
        player.setName(name);
        assertEquals("Invalid Input", game.getName());
    }
    @Test
    public void setDifficultyTest() {
        //Tests if {correct difficulty input} works
        GameSettings player = new GameSettings();
        String difficulty = "Easy";
        player.setDifficulty(difficulty);
        assertEquals("Easy", player.getDifficulty());

        difficulty = "Medium";
        player.setDifficulty(difficulty);
        assertEquals("Medium", player.getDifficulty());

        difficulty = "Hard";
        player.setDifficulty(difficulty);
        assertEquals("Hard", player.getDifficulty());
    }

    @Test
    public void setCharacterTest() {
        GameSettings player = Mockito.mock(GameSettings.class);
        //tests if the character matches the correct imageId selected
        when(player.getCharacter()).thenReturn(R.id.greenRangerButton);
        player.setCharacter(1000057);
        assertTrue(player.getCharacter() == R.id.greenRangerButton);

        when(player.getCharacter()).thenReturn(R.id.blueRangerButton);
        player.setCharacter(1000010);
        assertTrue(player.getCharacter() == R.id.blueRangerButton);

        when(player.getCharacter()).thenReturn(R.id.orangeRangerButton);
        player.setCharacter(1000009);
        assertTrue(player.getCharacter() == R.id.orangeRangerButton);

        when(player.getCharacter()).thenReturn(R.id.pinkRangerButton);
        player.setCharacter(1000037);
        assertTrue(player.getCharacter() == R.id.pinkRangerButton);

        when(player.getCharacter()).thenReturn(R.id.blackRangerButton);
        player.setCharacter(1000001);
        assertTrue(player.getCharacter() == R.id.blackRangerButton);
    }


    @Test
    public void setStartingLivesTest(){
        GameSettings player = new GameSettings();

        //easy
        String difficulty1 = "Easy";
        player.setDifficulty(difficulty1);
        assertEquals("10", player.getStartingLives());

        //medium
        String difficulty2 = "Medium";
        player.setDifficulty(difficulty2);
        assertEquals("5", player.getStartingLives());

        //hard
        String difficulty3 = "Hard";
        player.setDifficulty(difficulty3);
        assertEquals("3", player.getStartingLives());
    }


    @Test
    public void setScoreTest() {
        GameSettings player = new GameSettings();
        assertEquals("0", player.getScore());
    }

    @Test
    public void checkEqualMovementTest() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        int y = 600;
        int x = 600;
        when(player.getYCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setYCord(y);
        int shift = 60;
        when(player.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setXCord(x);
        player.setYCord(y);
        player.setXCord(x);
        player.setShift(shift);
        doCallRealMethod().when(drawGameObjects).up();
        doCallRealMethod().when(drawGameObjects).down();
        doCallRealMethod().when(drawGameObjects).left();
        doCallRealMethod().when(drawGameObjects).right();
        drawGameObjects.up();
        drawGameObjects.down();
        drawGameObjects.left();
        drawGameObjects.right();
        assertEquals(600, player.getYCord());
        assertEquals(600, player.getXCord());
    }

    @Test
    public void checkMovementUp() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        int y = 600;
        when(player.getYCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int shift = 60;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).up();
        player.up();
        assertEquals(540, player.getYCord());
    }

    @Test
    public void checkMovementLeftBoundaryLeft() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        int x = 460;
        when(player.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setXCord(x);
        player.setXCord(x);
        int shift = 60;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).left();
        player.left();
        assertEquals(400, player.getXCord());

        //check boundary doesn't move character off screen
        x = 11;
        when(player.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setXCord(x);
        player.setXCord(x);
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).left();
        player.left();
        assertEquals(11, player.getXCord());
    }
    @Test
    public void checkMovementRightBoundaryRight() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        int x = 460;
        when(player.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setXCord(x);
        player.setXCord(x);
        int shift = 60;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).right();
        player.right();
        assertEquals(520, player.getXCord());

        //check boundary doesn't move character off screen
        x = 840;
        when(player.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setXCord(x);
        player.setXCord(x);
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).right();
        player.right();
        assertEquals(840, player.getXCord());
    }

    @Test
    public void checkMovementDownBoundaryDown() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        int y = 600;
        when(player.getYCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        int shift = 60;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).down();
        player.down();
        assertEquals(660, player.getYCord());

        //check boundary doesn't move character off screen
        y = 1050;
        when(player.getYCord()).thenCallRealMethod();
        doCallRealMethod().when(player).setYCord(y);
        player.setYCord(y);
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).down();
        player.down();
        assertEquals(1050, player.getYCord());
    }



}

