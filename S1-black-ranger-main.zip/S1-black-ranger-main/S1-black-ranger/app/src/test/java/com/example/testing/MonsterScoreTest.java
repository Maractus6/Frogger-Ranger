package com.example.testing;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class)
public class MonsterScoreTest {

    @Test
    public void checkMonsterPumpkinMovement() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterPumpkin pumpkin = Mockito.mock(MonsterPumpkin.class);
        int x = 500;
        when(pumpkin.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(pumpkin).setXCord(x);
        pumpkin.setXCord(x);
        doCallRealMethod().when(pumpkin).moveMonster();
        pumpkin.moveMonster();
        assertEquals(410, pumpkin.getXCord());
    }

    @Test
    public void checkMonsterPumpkinBoundary() {
        //check boundary doesn't move pumpkin off screen
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterPumpkin pumpkin = Mockito.mock(MonsterPumpkin.class);
        int x = 0;

        when(pumpkin.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(pumpkin).setXCord(x);
        pumpkin.setXCord(x);
        when(pumpkin.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(pumpkin).setXCord(x);
        pumpkin.setXCord(x);
        doCallRealMethod().when(pumpkin).moveMonster();
        pumpkin.moveMonster();
        assertEquals(1100, pumpkin.getXCord());
    }

    @Test
    public void catMovementTest() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterCat cat = Mockito.mock(MonsterCat.class);
        int x = 460;
        when(cat.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(cat).setXCord(x);
        cat.setXCord(x);
        doCallRealMethod().when(cat).moveMonster();
        cat.moveMonster();
        assertEquals(500, cat.getXCord());

    }
    @Test
    public void catBorderTest() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterCat cat = Mockito.mock(MonsterCat.class);
        int x = 1000;
        when(cat.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(cat).setXCord(x);
        cat.setXCord(x);
        doCallRealMethod().when(cat).moveMonster();
        cat.moveMonster();
        assertEquals(-50, cat.getXCord());

    }
      @Test
    public void checkMonsterLizardMovementTest() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterLizard monsterLizard = Mockito.mock(MonsterLizard.class);
        int startingPositionX = 100;
        when(monsterLizard.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(monsterLizard).setXCord(startingPositionX);
        when(monsterLizard.getXCord()).thenCallRealMethod();
        monsterLizard.setXCord(startingPositionX);
        doCallRealMethod().when(monsterLizard).moveMonster();
        monsterLizard.moveMonster();
        assertEquals(110, monsterLizard.getXCord());
    }
    @Test
    public void checkMonsterLizardMovementBoundaryTest() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        MonsterLizard monsterLizard = Mockito.mock(MonsterLizard.class);
        int startingPositionX = 1000;
        when(monsterLizard.getXCord()).thenCallRealMethod();
        doCallRealMethod().when(monsterLizard).setXCord(startingPositionX);
        when(monsterLizard.getXCord()).thenCallRealMethod();
        monsterLizard.setXCord(startingPositionX);
        doCallRealMethod().when(monsterLizard).moveMonster();
        monsterLizard.moveMonster();
        assertEquals(-50, monsterLizard.getXCord());
    }
    
        @Test
    public void checkInitialScore(){
        GameSettings player = new GameSettings();
        assertEquals("0", player.getScore());
    }

    @Test
    public void checkScoreLizard(){
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = new GameSettings();
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        int y = 1150;
        player.setYCord(y);
        int shift = 80;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).up();
        player.up();
        int score = 2;
        int defaultVal = 0;
        when(player.getScore()).thenCallRealMethod();
        doCallRealMethod().when(player).setScore(score);
        player.setScore(score);
        assertEquals(2, player.getScore());
        game.setScore(defaultVal);
    }

    @Test
    public void checkScorePumpkin() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = new GameSettings();
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        int y = 1000;
        player.setYCord(y);
        int shift = 80;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).up();
        player.up();
        int score = 4;
        int defaultVal = 0;
        when(player.getScore()).thenCallRealMethod();
        doCallRealMethod().when(player).setScore(score);
        player.setScore(score);
        assertEquals(4, player.getScore());
        game.setScore(defaultVal);
    }
    @Test
    public void checkScoreCat() {
        DrawGameObjects drawGameObjects = Mockito.mock(DrawGameObjects.class);
        Player player = Mockito.mock(Player.class);
        GameSettings game = new GameSettings();
        doCallRealMethod().when(player).setGame(game);
        player.setGame(game);
        int y = 880;
        player.setYCord(y);
        int shift = 80;
        doCallRealMethod().when(player).setShift(shift);
        player.setShift(shift);
        doCallRealMethod().when(player).up();
        player.up();
        int score = 3;
        int defaultVal = 0;
        when(player.getScore()).thenCallRealMethod();
        doCallRealMethod().when(player).setScore(score);
        player.setScore(score);
        assertEquals(3, player.getScore());
        game.setScore(defaultVal);
    }
}
