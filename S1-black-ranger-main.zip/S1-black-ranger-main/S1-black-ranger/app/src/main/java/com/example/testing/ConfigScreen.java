package com.example.testing;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class ConfigScreen extends AppCompatActivity {
    private RadioGroup radioGroupDifficulty;
    private RadioGroup radioGroupCharacter;
    private RadioButton radioButtonDiff;
    private RadioButton radioButtonChar;
    private TextView textView;
    private TextInputEditText ve;
    private String stringInput;
    private Boolean nameIsEmpty = false;
    private TextInputEditText nameInput;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config_screen);

        textView = findViewById(R.id.characterSelected);

        ve = findViewById(R.id.nameInput);


        radioGroupDifficulty = findViewById(R.id.radioGroup);
        radioGroupCharacter = findViewById(R.id.radioGroupCharacter);
        nameInput = findViewById(R.id.nameInput);
        submitButton = findViewById(R.id.submit_button);
        ve.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = true;
                stringInput = ve.getText().toString().trim();
                    if (actionId == 0) {
                        if (stringInput == null || stringInput.equals("")) {
                            TextView nameTextView = (TextView) findViewById(R.id.displayNameInput);
                            nameTextView.setText("Invalid input.");
                        } else {

                            TextView nameTextView = (TextView) findViewById(R.id.displayNameInput);
                            nameTextView.setText("Your chosen name is " + stringInput);
                        }
                    }
                    return handled;
                }
            });
        nameInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkIfAllCriteriaMet();
            }

            @Override
            public void afterTextChanged(Editable s) {
                checkIfAllCriteriaMet();
            }
        });

        radioGroupDifficulty.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                checkIfAllCriteriaMet();
            }
        });

        radioGroupCharacter.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                checkIfAllCriteriaMet();
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String difficulty = "";
                int startingLives = 0;
                int characterId = 0;
                int difficultySelectedId = radioGroupDifficulty.getCheckedRadioButtonId();
                int characterDesignSelectedId = radioGroupCharacter.getCheckedRadioButtonId();

                if (difficultySelectedId == R.id.easyButton) {
                    difficulty = "Easy";
                    startingLives = 6;
                } else if (difficultySelectedId == R.id.mediumButton) {
                    difficulty = "Medium";
                    startingLives = 3;
                } else if (difficultySelectedId == R.id.hardButton) {
                    difficulty = "Hard";
                    startingLives = 2;
                }

                if (characterDesignSelectedId == R.id.greenRangerButton) {
                    characterId = R.drawable.green_ranger;
                } else if (characterDesignSelectedId == R.id.orangeRangerButton) {
                    characterId = R.drawable.orange_ranger;
                } else if (characterDesignSelectedId == R.id.pinkRangerButton) {
                    characterId = R.drawable.pink_ranger;
                } else if (characterDesignSelectedId == R.id.blueRangerButton) {
                    characterId = R.drawable.blue_ranger;
                } else if (characterDesignSelectedId == R.id.blackRangerButton) {
                    characterId = R.drawable.black_ranger;
                }

                String name = nameInput.getText().toString();
                GameSettings settings = new GameSettings(name, difficulty,
                        characterId, startingLives);

                Intent intent = new Intent(ConfigScreen.this, GameScreen.class);
                startActivity(intent);

            }
        });
    }

    public boolean checkIfAllCriteriaMet() {
        int difficultySelectedId = radioGroupDifficulty.getCheckedRadioButtonId();
        int characterDesignSelectedId = radioGroupCharacter.getCheckedRadioButtonId();
        String name = nameInput.getText().toString().trim();

        if (difficultySelectedId != -1 && characterDesignSelectedId != -1 && !name.isEmpty()) {
            submitButton.setVisibility(View.VISIBLE);
            return true;
        } else {
            submitButton.setVisibility(View.INVISIBLE);
            return false;
        }
    }

    public void checkButtonDifficulty(View v) {
        int radioIdDifficulty = radioGroupDifficulty.getCheckedRadioButtonId();
        radioButtonDiff = findViewById(radioIdDifficulty);
    }
    public void checkButtonCharacter(View v) {
        int radioIdCharacter = radioGroupCharacter.getCheckedRadioButtonId();
        radioButtonChar = findViewById(radioIdCharacter);
        String characterDesign = "dfg";
        if (radioButtonChar.getId() == (R.id.greenRangerButton)) {
            characterDesign = "Green Ranger!";
        } else if (radioButtonChar.getId() == (R.id.blueRangerButton)) {
            characterDesign = "Blue Ranger!";
        } else if (radioButtonChar.getId() == (R.id.orangeRangerButton)) {
            characterDesign = "Orange Ranger!";
        } else if (radioButtonChar.getId() == (R.id.pinkRangerButton)) {
            characterDesign = "Pink Ranger!";
        } else if (radioButtonChar.getId() == (R.id.blackRangerButton)) {
            characterDesign = "Black Ranger!";
        }
        textView.setText("Your choice: " + characterDesign);
    }

}