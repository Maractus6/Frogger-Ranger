package com.example.testing;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
//art credits to Kelvin Shadowing: https://opengameart.org/content/konqi-supertux-advance-style
public class MonsterLizard extends Monster {
    private int startingPositionX;
    private GameSettings game = new GameSettings();
    private Rect rect = new Rect();

    public MonsterLizard(int startingPosition) {
        this.startingPositionX = startingPosition;
        rect.set(startingPositionX, 1150, startingPositionX + 150, 1000);

    }

    public void moveMonster() {
        startingPositionX += 10;
        setXCord(startingPositionX);
        rect.set(startingPositionX, 1300, startingPositionX + 150, 1150);
        if (startingPositionX >= 1000) {
            startingPositionX = -50;
            setXCord(startingPositionX);
            rect.set(startingPositionX, 1300, startingPositionX + 150, 1150);
        }
    }

    public Bitmap createMonster(BitmapFactory bf) {
        Bitmap imgLizard = bf.decodeResource(game.getCurrContext().getResources(),
                getDefaultSprite());
        Bitmap scaledLizard = Bitmap.createScaledBitmap(imgLizard,
                150, 150, false);
        return scaledLizard;
    }
    public void setRectangle(Rect rectangle) {
        this.rect = rectangle;
    }
    public Rect getRectangle() {
        return rect;
    }

    public int getDefaultSprite() {
        return R.drawable.lizard;
    }

    public int getXCord() {
        return startingPositionX;
    }

    public void setXCord(int startingPositionX) {
        this.startingPositionX = startingPositionX;
    }
}


