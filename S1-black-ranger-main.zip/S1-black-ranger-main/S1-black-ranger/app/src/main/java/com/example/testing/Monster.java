package com.example.testing;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import java.util.Timer;



public abstract class Monster {
    private int x;
    private int y;

    private static Timer timer = new Timer();

    public abstract void moveMonster();

    public abstract int getDefaultSprite();
    public abstract Bitmap createMonster(BitmapFactory bf);
    public abstract Rect getRectangle();
    public Timer getTimer() {
        return timer;
    }
}
