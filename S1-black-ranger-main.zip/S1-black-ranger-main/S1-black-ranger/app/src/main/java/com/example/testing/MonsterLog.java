package com.example.testing;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import java.util.TimerTask;

public class MonsterLog extends Monster {
    private int startingPositionX;
    private int startingPositionY;
    private GameSettings game = new GameSettings();
    private Rect rect = new Rect();


    public MonsterLog(int startingPosition, int startingPositionY) {
        this.startingPositionX = startingPosition;
        this.startingPositionY = startingPositionY;
        rect.set(startingPositionX - 50, startingPositionY, startingPositionX + 50,
                startingPositionY - 100);
    }

    public void moveMonsterRight() {
        startingPositionX += 20;
        setXCord(startingPositionX);
        rect.set(startingPositionX, startingPositionY + 100, startingPositionX + 100,
                startingPositionY);
        if (startingPositionX >= 1000) {
            startingPositionX = -50;
            setXCord(startingPositionX);
            rect.set(startingPositionX, startingPositionY + 100, startingPositionX + 100,
                    startingPositionY);
        }
    }
    public void moveMonsterLeft() {
        startingPositionX -= 100;
        setXCord(startingPositionX);
        rect.set(startingPositionX, startingPositionY + 100, startingPositionX + 100,
                startingPositionY);
        if (startingPositionX <= -20) {
            startingPositionX = 1100;
            setXCord(startingPositionX);
            rect.set(startingPositionX, startingPositionY + 100, startingPositionX + 100,
                    startingPositionY);
        }
    }

    public void moveMonster() {
        getTimer().schedule(new TimerTask() {
            @Override
            public void run() {
                moveMonster();
            }
        }, 1000, 1000);
    }

    public Bitmap createMonster(BitmapFactory bf) {
        Bitmap imgLog = bf.decodeResource(game.getCurrContext().getResources(), getDefaultSprite());
        Bitmap scaledBitmapLog = Bitmap.createScaledBitmap(imgLog, 100, 100, false);
        return scaledBitmapLog;
    }
    public Rect getRectangle() {
        return rect;
    }
    public void setRectangle(Rect rectangle) {
        this.rect = rectangle;
    }

    public int getDefaultSprite() {
        return R.drawable.log;
    }
    public void setXCord(int startingPositionX) {
        this.startingPositionX = startingPositionX;
    }
    public int getXCord() {
        return startingPositionX;
    }

}