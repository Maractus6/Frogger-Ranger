package com.example.testing;
import android.content.Context;

public class GameSettings {
    private static String name = "Bob";
    private static String difficulty = "Easy";
    private static int character = R.drawable.black_ranger;
    private static int startingLives = 10;
    private static Context currContext;

    private static int score = 0;
    private static boolean gameOver = false;
    public GameSettings(String name, String difficulty, int character, int startingLives) {
        this.name = name;
        this.difficulty = difficulty;
        this.character = character;
        this.startingLives = startingLives;
        this.score = score;
    }
    public GameSettings() {

    }


    public static void setCurrContext(Context context) {
        currContext = context;
    }

    public static Context getCurrContext() {
        return currContext;
    }

    public void setName(String name) {
        if (name == null || name.trim().equals("")) {
            this.name = "Invalid Input";
        } else {
            this.name = name;
        }
    }
    public String getName() {
        return name;
    }
    public void setDifficulty(String difficulty) {

        this.difficulty = difficulty;
        if (difficulty == "Easy") {
            this.startingLives = 10;
        } else if (difficulty == "Medium") {
            this.startingLives = 5;
        } else {
            this.startingLives = 3;
        }
    }
    public String getDifficulty() {
        return difficulty;
    }
    public void setCharacter(int character) {
        this.character = character;
    }
    public int getCharacter() {
        return character;
    }
    public void setStartingLives(int startingLives) {
        this.startingLives = startingLives;
        this.gameOver = true;
    }
    public int getStartingLives() {
        return startingLives;
    }
    public void setScore(int score) {
        this.score = score;
    }

    public String getScore() {
        return Integer.toString(score);
    }

    public boolean getGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
        if (this.gameOver) {
            this.score = 0;
        }
    }

}
