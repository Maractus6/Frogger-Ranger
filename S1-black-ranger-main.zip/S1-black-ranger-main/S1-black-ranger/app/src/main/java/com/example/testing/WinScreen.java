package com.example.testing;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.TextView;

public class WinScreen extends AppCompatActivity {
    private Button restartButton;
    private Button exitGameButton;
    private GameSettings game;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_win_screen);

        GameSettings game = new GameSettings();
        this.game = game;

        TextView scoreTextView = findViewById(R.id.win_last_score);
        scoreTextView.setText("Score: " + game.getScore());

        restartButton = (Button) findViewById(R.id.win_restart_game);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game.setScore(0);
                configScreen();
                finish();
            }
        });

        exitGameButton = (Button) findViewById(R.id.win_exit_game);
        exitGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
                System.exit(0);

            }
        });
    }

    public void configScreen() {
        Intent intent = new Intent(this, ConfigScreen.class);
        startActivity(intent);
    }

}
