package com.example.testing;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import java.util.Timer;

import java.util.TimerTask;

public class DrawGameObjects extends androidx.appcompat.widget.AppCompatImageView {
    private int width;
    private int height;
    private boolean gameOver;
    private int characterChosen = R.drawable.black_ranger;
    private GameSettings game;
    private Player player;
    private BitmapFactory bf;
    private MonsterPumpkin mp = new MonsterPumpkin(0);
    private MonsterPumpkin mp1 = new MonsterPumpkin(500);
    private MonsterCat mc = new MonsterCat(10);
    private MonsterCat mc1 = new MonsterCat(420);
    private MonsterLizard ml = new MonsterLizard(850);
    private MonsterLizard ml1 = new MonsterLizard(450);

    private MonsterLog mLogb1 = new MonsterLog(0, 420);
    private MonsterLog mLogb2 = new MonsterLog(100, 420);
    private MonsterLog mLogb3 = new MonsterLog(200, 420);
    private MonsterLog mLog1 = new MonsterLog(500, 550);
    private MonsterLog mLog2 = new MonsterLog(400, 550);
    private MonsterLog mLog3 = new MonsterLog(300, 550);
    private MonsterLog mLogc1 = new MonsterLog(0, 290);
    private MonsterLog mLogc2 = new MonsterLog(100, 290);
    private MonsterLog mLogc3 = new MonsterLog(200, 290);
    private MonsterLog mLogd1 = new MonsterLog(500, 160);
    private MonsterLog mLogd2 = new MonsterLog(400, 160);
    private MonsterLog mLogd3 = new MonsterLog(300, 160);
    private River r = new River();
    private Collision collision;
    private Monster[] monsterArr = {mp, mp1, mc, mc1, ml, ml1, mLogb1, mLogb2, mLogb3,
        mLog1, mLog2, mLog3, mLogc2, mLogc3, mLogd1, mLogd2, mLogd3};
    public DrawGameObjects(Context context, AttributeSet attrs) {
        super(context, attrs);
        player = new Player();
        bf = new BitmapFactory();
        game = new GameSettings();
        game.setCurrContext(context);
        collision = new Collision();
        this.setBackgroundColor(Color.TRANSPARENT);
    }

    public void setCharacterChosen(int id) {
        characterChosen = id;
    }
    public int getCharacterChosen() {
        return game.getCharacter();
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int wMode = MeasureSpec.getMode(widthMeasureSpec);
        int wSize = MeasureSpec.getSize(widthMeasureSpec);
        int hMode = MeasureSpec.getMode(heightMeasureSpec);
        int hSize = MeasureSpec.getSize(heightMeasureSpec);

        if (wMode == MeasureSpec.EXACTLY) {
            width = wSize;
        } else if (wMode == MeasureSpec.AT_MOST) {
            width = 150;
        }

        if (hMode == MeasureSpec.EXACTLY) {
            height = hSize;
        } else if (hMode == MeasureSpec.AT_MOST) {
            height = 150;
        }

        setMeasuredDimension(width, height);
    }
    @Override
    public void onDraw(Canvas canvas) {
        long startTime = System.currentTimeMillis();
        Timer timer = new Timer();
        super.onDraw(canvas);
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);

        // Cats
        canvas.drawBitmap(mc.createMonster(bf), mc.getXCord(), 850, paint);
        canvas.drawBitmap(mc1.createMonster(bf), mc1.getXCord(), 850, paint);

        // Lizards
        canvas.drawBitmap(ml.createMonster(bf), ml.getXCord(), 1150, paint);
        canvas.drawBitmap(ml1.createMonster(bf), ml1.getXCord(), 1150, paint);

        // Pumpkins
        canvas.drawBitmap(mp.createMonster(bf), mp.getXCord(), 1020, paint);
        canvas.drawBitmap(mp1.createMonster(bf), mp1.getXCord(), 1020, paint);

        // Logs
        canvas.drawBitmap(mLogd1.createMonster(bf), mLogd1.getXCord(), 160, paint);
        canvas.drawBitmap(mLogd2.createMonster(bf), mLogd2.getXCord(), 160, paint);
        canvas.drawBitmap(mLogd3.createMonster(bf), mLogd3.getXCord(), 160, paint);
        canvas.drawBitmap(mLogc1.createMonster(bf), mLogc1.getXCord(), 290, paint);
        canvas.drawBitmap(mLogc2.createMonster(bf), mLogc2.getXCord(), 290, paint);
        canvas.drawBitmap(mLogc3.createMonster(bf), mLogc3.getXCord(), 290, paint);
        canvas.drawBitmap(mLogb1.createMonster(bf), mLogb1.getXCord(), 420, paint);
        canvas.drawBitmap(mLogb2.createMonster(bf), mLogb2.getXCord(), 420, paint);
        canvas.drawBitmap(mLogb3.createMonster(bf), mLogb3.getXCord(), 420, paint);
        canvas.drawBitmap(mLog1.createMonster(bf), mLog1.getXCord(), 550, paint);
        canvas.drawBitmap(mLog2.createMonster(bf), mLog2.getXCord(), 550, paint);
        canvas.drawBitmap(mLog3.createMonster(bf), mLog3.getXCord(), 550, paint);

        // Player
        Bitmap img = bf.decodeResource(game.getCurrContext().getResources(),
                getCharacterChosen());
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(img, 200, 200, false);
        canvas.drawBitmap(scaledBitmap, player.getXCord(), player.getYCord(), paint);
    }

    public void down() {
        player.down();
        invalidate();
    }

    public void up() {
        player.up();
        invalidate();
    }

    public void right() {
        player.right();
        invalidate();
    }

    public void moveMonsterActual() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                mc.moveMonster();
                mc1.moveMonster();
                mp.moveMonster();
                mp1.moveMonster();
                ml.moveMonster();
                ml1.moveMonster();
                mLogb1.moveMonsterLeft();
                mLogb2.moveMonsterLeft();
                mLogb3.moveMonsterLeft();
                mLog1.moveMonsterRight();
                mLog2.moveMonsterRight();
                mLog3.moveMonsterRight();
                mLogc1.moveMonsterRight();
                mLogc2.moveMonsterRight();
                mLogc3.moveMonsterRight();
                mLogd1.moveMonsterLeft();
                mLogd2.moveMonsterLeft();
                mLogd3.moveMonsterLeft();
                playerHitBorder();
                player.moveWithLog();
                isGameRunning();
                invalidate();
            }
        }, 1000, 2000);
    }

    public void left() {
        player.left();
        invalidate();
    }
    public void move() {
        moveMonsterActual();
    }

    public void isGameRunning() {
        collision.checkCollision(player, player.getRectangle(), r.getRectangle());
        if (collision.getCollided()) {
            resetRound();
        } else {
            collision.setCollided(true);
            for (Monster m : monsterArr) {
                collision.checkCollision(player, player.getRectangle(), m.getRectangle());
                if (!collision.checkWater(player, player.getRectangle())) {
                    resetRound();
                }
            }
            resetRound();
        }
    }


    public void resetRound() {
        boolean collided = collision.getCollided();
        if (collided) {
            if (game.getStartingLives() > 1) {
                game.setScore(0);
                player.setScore(0);
            }
            game.setStartingLives(game.getStartingLives() - 1);
            player.resetCharacter();
            collision.setCollided(false);
        }
        collision.setGameStatus(true);
    }
    public void playerHitBorder() {
        if (player.getXCord() >= 935 || player.getXCord() <= -50) {
            resetRound();
        }
    }

    public void setCollision(Collision collision) {
        this.collision = collision;
    }
    public void setGame(GameSettings gameSettings) {
        this.game = gameSettings;
    }
    public GameSettings getGame() {
        return game;
    }
    public void setPlayer(Player player) {
        this.player = player;
    }

    public Player getPlayer(){return this.player;}
}