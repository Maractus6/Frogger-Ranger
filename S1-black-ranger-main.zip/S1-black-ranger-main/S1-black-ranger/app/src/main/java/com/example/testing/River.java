package com.example.testing;

import android.graphics.Rect;

public class River {
    private Rect rect;
    public River() {
        rect = new Rect(-50, 935, 935, 400);
    }
    public Rect getRectangle() {
        return rect;
    }

}
