package com.example.testing;

import android.content.Intent;
import android.graphics.Rect;

public class Player {
    private int height;
    private int x;
    private int y;
    private int shift;
    private int characterChosen;
    private GameSettings game;
    private int score;
    private int netDifference;

    private int max;
    private Rect rectangle;
    private final int width = 100;

    public Player() {
        x = 460;
        y = 1290;
        shift = 80;
        rectangle = new Rect();
        rectangle.set(x + 45, y + width + 60, x + width + 45, y + 60);
        game = new GameSettings();
    }

    public void setCharacterChosen(int id) {
        characterChosen = id;
    }

    public int getCharacterChosen() {
        return game.getCharacter();
    }
    public void setRectangle(Rect rectangle) {
        this.rectangle = rectangle;
        //rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
    }

    public Rect getRectangle() {
        //rectangle.set(x, y + 200, x + 200, y);
        return rectangle;
    }
    public void setXCord(int x) {
        this.x = x;
    }

    public int getXCord() {
        return x;
    }

    public void setYCord(int y) {
        this.y = y;
    }

    public int getYCord() {
        return y;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    public int getShift() {

        return shift;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setGame(GameSettings game) {
        this.game = game;
    }

    public GameSettings getGame() {
        return game;
    }

    public void resetCharacter() {
        this.x = 460;
        this.y = 1290;
        rectangle.set(x + 45, y + width + 60, x + width + 45, y + 60);
    }
    public void down() {
        if (y >= 720) {
            if ((y + shift) <= 1300) {
                y += shift;
            }
        } else {
            if ((y + shift) <= 1300) {
                y += (shift + 50);
            }
        }
        rectangle.set(x + 45, y + width + 60, x + width + 45, y + 60);
        this.netDifference -= 1;
    }

    public void up() {
        int old = this.netDifference;
        System.out.println(y);
        if (y >= 720) {
            if ((y - shift) > -15) {
                y -= shift;
            }
            rectangle.set(x + 45, y + width + 60, x + width + 45, y + 60);
            this.netDifference += 1;
        } else {
            if ((y - shift) > -15) {
                y -= (shift + 50);
            }
            rectangle.set(x + 45, y + width + 60, x + width + 45, y + 60);
            this.netDifference += 1;
        }
        scoreMath(netDifference);
    }
    public void scoreMath(int netDifference) {
        if (netDifference > max) {
            if (1150 >= y && y > 1000) {
                this.score += 2;
            } else if (1000 >= y && y > 880) {
                this.score += 4;
            } else if (880 >= y && y > 660) {
                this.score += 3;
            } else if (y<=50) {
                this.score += 6;
            }else {
                this.score += 1;
            }
            max = netDifference;
            game.setScore(score);
        }
    }


    public void right() {
        if ((x + shift) <= 935) {
            x += shift;
        }
        rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
    }

    public void left() {
        if ((x - shift) > -50) {
            x -= shift;
        }
        rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
    }
    public void moveWithLog() {
        switch (y) {
        case 130:
            x -= 100;
            rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
            break;
        case 520:
            x += 20;
            rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
            break;
        case 390:
            System.out.println("Case 2");
            x -= 100;
            rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
            break;
        case 260:
            System.out.println("Case 3");
            x += 20;
            rectangle.set(x + 45, y + 100 + 60, x + 100 + 45, y + 60);
            break;
        default:
            break;
        }

    }
}