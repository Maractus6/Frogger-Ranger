package com.example.testing;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
//art credits to dogchicken: https://opengameart.org/content/cat-fighter-sprite-sheet
public class MonsterCat extends Monster {
    private int startingPositionX;
    private GameSettings game = new GameSettings();
    private Rect rect = new Rect();


    public MonsterCat(int startingPosition) {
        this.startingPositionX = startingPosition;
        rect.set(startingPositionX - 50, 850, startingPositionX + 50, 750);
    }

    public void moveMonster() {
        startingPositionX += 40;
        setXCord(startingPositionX);
        rect.set(startingPositionX, 950, startingPositionX + 100, 850);
        if (startingPositionX >= 1000) {
            startingPositionX = -50;
            setXCord(startingPositionX);
            rect.set(startingPositionX, 950, startingPositionX + 100, 850);
        }
    }

    public Bitmap createMonster(BitmapFactory bf) {
        Bitmap imgCat = bf.decodeResource(game.getCurrContext().getResources(), getDefaultSprite());
        Bitmap scaledBitmapCat = Bitmap.createScaledBitmap(imgCat, 100, 100, false);
        return scaledBitmapCat;
    }
    public Rect getRectangle() {
        return rect;
    }
    public void setRectangle(Rect rectangle) {
        this.rect = rectangle;
    }

    public int getDefaultSprite() {
        return R.drawable.cat1;
    }
    public int getXCord() {
        return startingPositionX;
    }
    public void setXCord(int startingPositionX) {
        this.startingPositionX = startingPositionX;
    }
}
