package com.example.testing;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class GameScreen extends AppCompatActivity {
    //    private boolean gameOver = true;
    private DrawGameObjects drawGameObjects;
    private GameSettings game;
    private Button upBtn;
    private Button downBtn;
    private Button leftBtn;
    private Button rightBtn;
    private DrawGameObjects character;
    private MonsterPumpkin pumpkin;
    private boolean gameOver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);
        GameSettings game = new GameSettings();

        this.game = game;

        TextView difficultyTextView = findViewById(R.id.chosenDifficulty);
        difficultyTextView.setText("Difficulty: " + game.getDifficulty());

        TextView startingLivesTextView = findViewById(R.id.livesLeft);
        startingLivesTextView.setText("Lives Left: " + game.getStartingLives());

        TextView nameTextView = findViewById(R.id.inputtedName);
        nameTextView.setText("Name: " + game.getName());

        TextView scoreTextView = findViewById(R.id.score);
        scoreTextView.setText("Score: " + game.getScore());

        character = (DrawGameObjects) findViewById(R.id.character);
        character.setCharacterChosen(game.getCharacter());


        upBtn = (Button) findViewById(R.id.up);
        downBtn = (Button) findViewById(R.id.down);
        leftBtn = (Button) findViewById(R.id.left);
        rightBtn = (Button) findViewById(R.id.right);

        upBtn.setOnClickListener(new DpadKeyListener());
        downBtn.setOnClickListener(new DpadKeyListener());
        leftBtn.setOnClickListener(new DpadKeyListener());
        rightBtn.setOnClickListener(new DpadKeyListener());
        character.move();
        updateValues();
    }

    public void updateScore() {
        TextView scoreView = findViewById(R.id.score);
        scoreView.setText("Score: " + game.getScore());
    }

    public void updateLives() {
        TextView startingLivesTextView = findViewById(R.id.livesLeft);
        if (game.getStartingLives() > 0) {
            startingLivesTextView.setText("Lives Left: " + game.getStartingLives());
        }


    }
    public void updateValues() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    if (game.getStartingLives() <= 0) {
                        timer.cancel();
                        //timer.purge();
                        Intent intent = new Intent(GameScreen.this, GameOver.class);
                        startActivity(intent);
                    }
                    updateScore();
                    updateLives();

                });
            }
        }, 1000, 500);

    }

    public DrawGameObjects getCharacter() {
        return character;
    }

    private class DpadKeyListener implements View.OnClickListener {
        public void onClick(View v) {
            switch (v.getId()) {
            case R.id.up:
                character.up();
                updateScore();
                if (character.getPlayer().getYCord()<=50){
                    Intent intent = new Intent(GameScreen.this, WinScreen.class);
                    startActivity(intent);
                }
                break;
            case R.id.down:
                character.down();
                break;
            case R.id.left:
                character.left();
                break;
            case R.id.right:
                character.right();
                break;
            default:
                break;
            }
        }
    }
}
