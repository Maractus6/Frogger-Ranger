package com.example.testing;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
// art credits to Emcee Flesher: https://opengameart.org/content/pumpkin-hat-for-16x16-chibi-rpg-characters
public class MonsterPumpkin extends Monster {
    private int startingPositionX;
    private GameSettings game = new GameSettings();
    private Rect rect = new Rect();
    public MonsterPumpkin(int startingPosition) {
        this.startingPositionX = startingPosition;
        rect.set(startingPositionX, 1120, startingPositionX + 100, 1020);
    }

    public void moveMonster() {
        startingPositionX -= 90;
        setXCord(startingPositionX);
        rect.set(startingPositionX, 1120, startingPositionX + 100, 1020);
        if (startingPositionX <= -20) {
            startingPositionX = 1100;
            setXCord(startingPositionX);
            rect.set(startingPositionX, 1120, startingPositionX + 100, 1020);
        }
    }

    public Bitmap createMonster(BitmapFactory bf) {
        Bitmap imgPumpkin = bf.decodeResource(game.getCurrContext().getResources(),
                getDefaultSprite());
        Bitmap scaledPumpkin = Bitmap.createScaledBitmap(imgPumpkin, 100,
                100, false);
        return scaledPumpkin;
    }
    public Rect getRectangle() {
        return rect;
    }
    public void setRectangle(Rect rectangle) {
        this.rect = rectangle;
    }

    public int getXCord() {
        return startingPositionX;
    }
    public void setXCord(int startingPositionX) {
        this.startingPositionX = startingPositionX;
    }

    public int getDefaultSprite() {
        return R.drawable.pumpkin1;
    }

}
