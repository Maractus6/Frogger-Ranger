package com.example.testing;

import android.graphics.Rect;

public class Collision {
    private boolean gameStatus = true;
    private static boolean collided = true;
    private GameSettings game = new GameSettings();
    public void checkCollision(Player player, Rect pHitbox, Rect monster) {
        boolean collision = (monster.centerX() + 50 > (pHitbox.centerX() - 50)
                && monster.centerX() - 50 < (pHitbox.centerX() + 50))
                && (monster.centerY() - 50 < (pHitbox.centerY() + 50)
                && monster.centerY() + 50 > (pHitbox.centerY() - 50));

        if (checkWater(player, pHitbox)) {
            collided =  collided && !collision;
        } else {
            collided = collision;
        }
    }
    public boolean checkWater(Player player, Rect pHitbox) {
        return ((pHitbox.centerY() - 50) < 680) && ((pHitbox.centerY() + 50) > 180);
    }

    public boolean getCollided() {
        return collided;
    }

    public void setCollided(boolean collided) {
        this.collided = collided;
    }

    public boolean getGameStatus() {
        return gameStatus;
    }

    public void setGameStatus(boolean gameStatus) {
        this.gameStatus = gameStatus;
    }

    public void setGameOver(boolean gameOver) {
        this.gameStatus = gameOver;
    }
}
